/*=Plus=header=begin======================================================
Program: Plus
Copyright (c) Laboratory for Percutaneous Surgery. All rights reserved.
See License.txt for details.

Developed by ULL & IACTEC-IAC group
=========================================================Plus=header=end*/

#ifndef __vtkInfraredTEEV2Cam_h
#define __vtkInfraredTEEV2Cam_h

#include "vtkPlusDataCollectionExport.h"
#include "vtkPlusDevice.h"

namespace i3
{
	class TE_A; // FM MODIFICACION 2023-01-09: Cambio de tipo para EV2:  class TE_B;
}

/*!
\class vtkInfraredTEEV2Cam
\brief Class for interfacing an Infrared Seek capture device and recording frames into a Plus buffer

\ingroup PlusLibDataCollection
*/

class vtkPlusDataCollectionExport vtkInfraredTEEV2Cam : public vtkPlusDevice
{
public:
  static vtkInfraredTEEV2Cam* New();
  vtkTypeMacro(vtkInfraredTEEV2Cam, vtkPlusDevice);
  virtual void PrintSelf(ostream& os, vtkIndent indent) VTK_OVERRIDE;

  /*! Read configuration from xml data */
  PlusStatus ReadConfiguration(vtkXMLDataElement* config);
  /*! Write configuration to xml data */
  PlusStatus WriteConfiguration(vtkXMLDataElement* config);

  /*! Manage device frozen state */
  PlusStatus FreezeDevice(bool freeze);

  /*! Is this device a tracker */
  bool IsTracker() const { return false; }

  /*! Get an update from the tracking system and push the new transforms to the tools. This function is called by the tracker thread.*/
  PlusStatus InternalUpdate();

  /*! Verify the device is correctly configured */
  virtual PlusStatus NotifyConfigured();

protected:
  vtkInfraredTEEV2Cam();
  ~vtkInfraredTEEV2Cam();

  virtual PlusStatus InternalConnect() VTK_OVERRIDE;
  virtual PlusStatus InternalDisconnect() VTK_OVERRIDE;

protected:
  int device;

  i3::TE_A* pTE; // FM MODIFICACION 2023-01-09: Cambio de tipo para EV2: i3::TE_B* pTE;
  unsigned short* pImgBuf; // FM MODIFICACION 2023-01-09: Cambio de tipo para EV2: float* pImgBuf;
  int width;
  int height;
};

#endif // __vtkInfraredTEEV2Cam_h
